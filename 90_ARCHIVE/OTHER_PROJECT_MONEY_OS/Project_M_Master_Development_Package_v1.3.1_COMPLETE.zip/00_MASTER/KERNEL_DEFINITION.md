# Money OS Kernel v1.3.1

The Kernel is shared infrastructure. It is NOT the centralized business strategist.

## Shared Economic Infrastructure
- Budget Manager
- Financial Ledger
- cost attribution
- revenue/profit accounting
- Operating Capital boundaries
- approval and governance

## Shared AI Runtime
- model gateway/router
- agent runtime/orchestration primitives
- scheduler / long-running loop support
- state/checkpoints
- observability
- retries/failure handling
- memory infrastructure

## Shared Capability Infrastructure
- Shared Capability Registry
- approved MCP/Skills/connectors
- browser/testing/research capabilities
- capability security, permissions, cost and health metadata

## Shared Governance
- Autonomous Business Constitution
- security and legal boundaries
- approval rules
- auditability

The Kernel supplies common infrastructure. Each Business Brain independently owns domain understanding, strategy, opportunity discovery, capability acquisition, execution choices, measurement and mandatory self-iteration.
