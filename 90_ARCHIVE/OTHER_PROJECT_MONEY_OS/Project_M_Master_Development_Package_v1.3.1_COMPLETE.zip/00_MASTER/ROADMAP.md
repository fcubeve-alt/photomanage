# Roadmap v1.3

## Step 0 - Repository Reconciliation
Map existing Project M, Monetools and LUVYMIA automation assets. Preserve useful execution capabilities. Identify duplicate local “brains” that should not compete with the new architecture.

## Step 1 - Kernel Minimum Viable Runtime
Budget, Ledger, Approval, Model Runtime, Scheduler, State, Observability, Memory Infrastructure, Shared Capability Registry and Constitution enforcement primitives.

## Step 2 - Autonomous Brain Runtime Contract
Implement the continuous business loop and requirements for strategy generation, evidence retrieval, capability acquisition, reflection and replanning.

## Step 3 - M2-B Monetools First Brain Pilot
Handoff the current business state. Brain performs Autonomous Business Audit, identifies missing capabilities, requests only human-only permissions, generates/executes strategy and iterates from live data.

## Step 4 - M1 / M2-A
Attach distinct autonomous brains using the same Kernel but different domain intelligence.

## Step 5 - Cross-business learning
Share only genuinely reusable infrastructure/lessons; preserve domain-specific business memory inside each Brain.

## Step 6 - M2-C activation decision
Only after Kernel and autonomy loop are stable.
