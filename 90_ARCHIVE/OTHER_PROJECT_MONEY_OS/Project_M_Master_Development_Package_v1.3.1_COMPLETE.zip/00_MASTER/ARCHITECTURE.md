# Project M Architecture v1.3.1

Project M has three conceptual layers.

## Layer 1 — Money OS Kernel
Shared infrastructure, economics, governance and runtime.
The Kernel is not the business brain.

## Layer 2 — Autonomous Business Brains
M1, M2-A, M2-B and later M2-C each own their own domain intelligence and business operation.

Every Business Brain must:
- own its Mission;
- create and change strategy;
- create/kill/reorder its own tasks;
- conduct fresh research;
- discover opportunities;
- discover/acquire capabilities;
- execute;
- measure real outcomes;
- challenge its own assumptions;
- perform Mandatory Self-Iteration;
- escalate only irreducible human-required actions.

## Layer 3 — Real Business Assets / External Economy
M1: external labor markets and customers.
M2-A: LUVYMIA.
M2-B: Monetools.
M2-C: Cubewithin (designed/not active).

## Critical distinction
Shared does NOT mean centralized strategy.
The Kernel provides common infrastructure.
Each Business Brain is the autonomous operator/CEO of its own economic domain.

## Inheritance
Every Business Brain inherits:
`AUTONOMOUS_BUSINESS_CONSTITUTION.md`.

Goal stable. Strategy adaptive. Tasks disposable.
