# Development Rules v1.3

1. ONE KERNEL, MULTIPLE AUTONOMOUS BUSINESS BRAINS.
2. Kernel is shared infrastructure, not centralized business strategy.
3. Each Business Brain owns its strategy, plans and task generation.
4. MANDATORY SELF-ITERATION: observe, test, measure, self-criticize, revise and repeat. Never freeze a method merely because it was previously chosen.
5. Goals/constraints relatively stable; strategy adaptive; tasks disposable.
6. Reuse before build.
7. Capability acquisition is a first-class behavior.
8. Fresh evidence first for dynamic external facts.
9. Access failure does not end research; run Access Recovery Loop.
10. Solve before escalate. Human assistance is last-level and minimal.
11. Common capabilities belong in Shared Capability Registry when genuinely reusable.
12. Do not preinstall every possible tool; acquire capabilities when evidence/need justifies them.
13. Deterministic economic/governance rules belong in code, not prompts.
14. Every paid call reserves and settles budget.
15. Ledger is append-only and authoritative for economic facts.
16. High-risk actions cannot bypass governance.
17. Economic/business memory must link to real outcomes.
18. Track hidden costs and human minutes.
19. Never fabricate identity, reviews, credentials, metrics, claims or current evidence.
20. Business Brain does not declare DONE merely because current tasks are finished; it returns to observation while mission is active.
