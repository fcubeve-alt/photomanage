# Shared Capability Infrastructure v1.3

Project M Kernel provides shared infrastructure, not centralized business strategy.

## A. Economic/Governance Infrastructure
- Budget Manager
- Financial Ledger
- Approval Gate
- risk / permission policies
- audit trail

## B. AI Runtime Infrastructure
- Model Router/Gateway
- Agent runtime/orchestration primitives
- scheduler / recurring wakeups
- durable state / checkpoints
- persistent memory infrastructure
- observability

## C. Shared Capability Registry
Reusable capabilities may include:
- browser testing/automation (e.g. Playwright where appropriate)
- current documentation retrieval (e.g. Context7-class capability)
- structured web research/extraction (e.g. Firecrawl-class capability)
- persistent project memory
- task/dependency management
- web/search/read adapters
- GitHub/coding/file/media tools
- approved MCP/Skills/APIs/CLIs

The Registry must record capability, permissions, cost, security, auth, reliability, version, and allowed scopes.

## D. Capability Acquisition Engine
Every Business Brain may discover a missing capability and request/acquire it through a controlled process:
Need -> Search shared registry -> Search external current solutions -> Compare -> Integrate/Acquire -> Smoke test -> Register -> Use -> Measure.

The Kernel offers the infrastructure for acquiring and governing capabilities. The Business Brain decides which capabilities are relevant to its business.
