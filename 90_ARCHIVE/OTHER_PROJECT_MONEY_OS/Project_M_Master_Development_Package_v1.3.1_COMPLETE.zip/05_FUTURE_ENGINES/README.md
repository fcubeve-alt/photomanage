Reserved for M3–M11. Do not implement in v1.2.
