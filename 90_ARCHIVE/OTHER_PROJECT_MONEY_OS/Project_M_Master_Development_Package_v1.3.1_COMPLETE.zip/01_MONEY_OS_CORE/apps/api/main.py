from fastapi import FastAPI

app = FastAPI(title="Project M Money OS", version="0.5.0")

@app.get("/health")
async def health():
    return {"status":"ok","version":"0.5.0"}

@app.get("/v1/dashboard/summary")
async def summary():
    return {
        "revenue":0,
        "ai_cost":0,
        "net_profit":0,
        "active_tasks":0,
        "pending_approvals":0
    }
