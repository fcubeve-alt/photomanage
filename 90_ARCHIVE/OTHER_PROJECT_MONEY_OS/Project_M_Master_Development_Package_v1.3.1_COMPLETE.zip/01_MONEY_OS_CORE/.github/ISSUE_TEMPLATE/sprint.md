---
name: Project M Sprint Task
about: Engineering task
title: "[Sx] "
---

## Objective
## Scope
## Acceptance criteria
- [ ]
## Tests
- [ ]
## Cost impact
## Risk / approval impact
## Out of scope
