from decimal import Decimal
from pydantic import BaseModel, Field
from .contracts import RiskLevel

class TaskContract(BaseModel):
    task_id: str
    objective: str
    inputs: dict = Field(default_factory=dict)
    constraints: list[str] = Field(default_factory=list)
    deliverables: list[str]
    acceptance_criteria: list[str]
    max_ai_spend: Decimal
    max_tool_spend: Decimal = Decimal("0")
    max_retries: int = 1
    allowed_tools: list[str] = Field(default_factory=list)
    risk_level: RiskLevel = "R1"
