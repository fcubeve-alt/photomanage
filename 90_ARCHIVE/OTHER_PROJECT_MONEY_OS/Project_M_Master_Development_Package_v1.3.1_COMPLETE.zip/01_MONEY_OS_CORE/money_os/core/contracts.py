from __future__ import annotations
from typing import Any, Literal, Protocol
from decimal import Decimal
from pydantic import BaseModel, Field

Decision = Literal["TAKE","WATCH","KILL"]
RiskLevel = Literal["R0","R1","R2","R3","R4"]

class MoneyContext(BaseModel):
    workspace_id: str
    project_id: str | None = None
    task_id: str | None = None
    run_id: str | None = None

class OpportunityCandidate(BaseModel):
    source_key: str
    external_id: str | None = None
    title: str
    raw_text: str
    offered_value: Decimal | None = None
    currency: str = "USD"
    metadata: dict[str, Any] = Field(default_factory=dict)

class OpportunityEvaluation(BaseModel):
    total_score: float
    expected_value: Decimal
    estimated_ai_cost: Decimal
    success_probability: float
    risk_level: RiskLevel
    decision: Decision
    evidence_ids: list[str] = Field(default_factory=list)

class ExecutionPlan(BaseModel):
    objective: str
    deliverables: list[str]
    acceptance_criteria: list[str]
    allowed_tools: list[str]
    max_ai_spend: Decimal
    max_tool_spend: Decimal = Decimal("0")
    max_retries: int = 1
    risk_level: RiskLevel = "R1"

class MoneyEnginePlugin(Protocol):
    key: str
    async def discover(self, ctx: MoneyContext): ...
    async def evaluate(self, opportunity, ctx: MoneyContext): ...
    async def plan(self, opportunity, ctx: MoneyContext): ...
    async def execute(self, plan, ctx: MoneyContext): ...
    async def qa(self, result, ctx: MoneyContext): ...
    async def deliver(self, result, ctx: MoneyContext): ...
    async def learn(self, outcome, ctx: MoneyContext): ...
