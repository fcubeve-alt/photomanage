CREATE EXTENSION IF NOT EXISTS vector;

CREATE TABLE IF NOT EXISTS workspaces (
 id UUID PRIMARY KEY,
 name TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'active',
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS opportunities (
 id UUID PRIMARY KEY,
 workspace_id UUID NOT NULL REFERENCES workspaces(id),
 source_key TEXT NOT NULL,
 external_id TEXT,
 title TEXT NOT NULL,
 raw_text TEXT NOT NULL,
 currency TEXT NOT NULL DEFAULT 'USD',
 offered_value NUMERIC(18,6),
 status TEXT NOT NULL,
 fingerprint TEXT NOT NULL,
 discovered_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS ux_opportunity_fingerprint
ON opportunities(workspace_id, fingerprint);

CREATE TABLE IF NOT EXISTS tasks (
 id UUID PRIMARY KEY,
 opportunity_id UUID REFERENCES opportunities(id),
 task_type TEXT NOT NULL,
 status TEXT NOT NULL,
 requirements_json JSONB NOT NULL DEFAULT '{}'::jsonb,
 max_ai_spend NUMERIC(18,8) NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS runs (
 id UUID PRIMARY KEY,
 task_id UUID NOT NULL REFERENCES tasks(id),
 agent_role TEXT,
 status TEXT NOT NULL,
 checkpoint_json JSONB NOT NULL DEFAULT '{}'::jsonb,
 failure_reason TEXT,
 started_at TIMESTAMPTZ,
 ended_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS budgets (
 id UUID PRIMARY KEY,
 scope_type TEXT NOT NULL,
 scope_id UUID NOT NULL,
 limit_amount NUMERIC(18,8) NOT NULL,
 spent_amount NUMERIC(18,8) NOT NULL DEFAULT 0,
 reserved_amount NUMERIC(18,8) NOT NULL DEFAULT 0,
 hard_stop BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS approval_requests (
 id UUID PRIMARY KEY,
 workspace_id UUID NOT NULL REFERENCES workspaces(id),
 run_id UUID REFERENCES runs(id),
 action_type TEXT NOT NULL,
 risk_level TEXT NOT NULL,
 payload_json JSONB NOT NULL DEFAULT '{}'::jsonb,
 status TEXT NOT NULL DEFAULT 'pending',
 requested_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS ledger_entries (
 id UUID PRIMARY KEY,
 workspace_id UUID NOT NULL REFERENCES workspaces(id),
 engine_key TEXT NOT NULL,
 opportunity_id UUID REFERENCES opportunities(id),
 task_id UUID REFERENCES tasks(id),
 run_id UUID REFERENCES runs(id),
 entry_type TEXT NOT NULL,
 amount NUMERIC(18,8) NOT NULL,
 currency TEXT NOT NULL DEFAULT 'USD',
 realized BOOLEAN NOT NULL DEFAULT TRUE,
 evidence_ref TEXT,
 occurred_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS economic_outcomes (
 id UUID PRIMARY KEY,
 task_id UUID REFERENCES tasks(id),
 opportunity_id UUID REFERENCES opportunities(id),
 accepted BOOLEAN,
 gross_revenue NUMERIC(18,8) NOT NULL DEFAULT 0,
 net_profit NUMERIC(18,8) NOT NULL DEFAULT 0,
 ai_cost NUMERIC(18,8) NOT NULL DEFAULT 0,
 tool_cost NUMERIC(18,8) NOT NULL DEFAULT 0,
 human_minutes INTEGER NOT NULL DEFAULT 0,
 rework_count INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS economic_memories (
 id UUID PRIMARY KEY,
 memory_type TEXT NOT NULL,
 subject_key TEXT NOT NULL,
 summary TEXT NOT NULL,
 metrics_json JSONB NOT NULL DEFAULT '{}'::jsonb,
 embedding vector(1536),
 source_outcome_ids UUID[] NOT NULL DEFAULT '{}',
 confidence DOUBLE PRECISION NOT NULL DEFAULT 0,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
