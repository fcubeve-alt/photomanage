# Sprint Issues

## S0
- [ ] FastAPI bootstrap
- [ ] Postgres + pgvector
- [ ] SQLAlchemy + Alembic
- [ ] Docker Compose
- [ ] config
- [ ] health checks
- [ ] contract tests

## S1
- [ ] Budget Manager
- [ ] Append-only Ledger
- [ ] Approval Gate
- [ ] State machines
- [ ] hard-stop tests

## S2
- [ ] ModelGatewayPort
- [ ] LiteLLM adapter
- [ ] Project M pricing
- [ ] model_call persistence
- [ ] Langfuse adapter

## S3
- [ ] Tool Registry
- [ ] risk policy
- [ ] cost reservation
- [ ] cache
- [ ] read-only search/browser adapters

## S4
- [ ] Opportunity ingest
- [ ] normalize
- [ ] dedupe
- [ ] hard filters
- [ ] scoring
- [ ] EV
- [ ] Take/Watch/Kill

## S5
- [ ] OrchestratorPort
- [ ] PraisonAI adapter
- [ ] Builder
- [ ] QA
- [ ] checkpoints

## S6
- [ ] EconomicOutcome
- [ ] EconomicMemory
- [ ] pgvector retrieval

## S7
- [ ] M1 source
- [ ] proposal draft
- [ ] coding workflow
- [ ] research/data workflow
- [ ] delivery package

## S8
- [ ] dashboard
- [ ] approvals
- [ ] ledger
- [ ] model economics

## S9
- [ ] $100 max-loss pilot
- [ ] 200 opportunities
- [ ] calibrate top 30
- [ ] limited real applications
- [ ] first closed real outcome
