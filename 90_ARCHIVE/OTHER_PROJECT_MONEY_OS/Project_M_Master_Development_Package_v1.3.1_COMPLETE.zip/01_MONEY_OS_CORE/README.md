# Project M — AI Money OS
## v0.5 Executable Construction Package

Goal: build the Money OS Core plus the first Money Engine, M1 AI Digital Worker.

Economic loop:
Opportunity → Evaluate → Approve → Execute → QA → Deliver → Revenue → Ledger → Learn

## Non-negotiable rules
1. Money OS, not one bot.
2. Tool first, model second.
3. Cheap capable model first.
4. Budget, ledger, approval and state machines are deterministic code.
5. Agents are workers, never the source of truth.
6. Every paid call belongs to a task and budget.
7. R3/R4 actions cannot bypass Approval Gate.
8. Ledger is append-only.
9. Every completed run creates an Economic Outcome.
10. Reuse mature open-source infrastructure before building custom infrastructure.

Read:
1. docs/architecture.md
2. docs/domain-model.md
3. docs/m1-digital-worker.md
4. docs/development-plan.md
5. CLAUDE_CODE_MASTER_PROMPT.md
