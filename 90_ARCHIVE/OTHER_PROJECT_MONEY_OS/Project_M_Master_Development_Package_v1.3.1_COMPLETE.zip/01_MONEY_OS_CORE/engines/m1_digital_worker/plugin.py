class M1DigitalWorkerPlugin:
    key = "M1_DIGITAL_WORKER"

    async def discover(self, ctx):
        return []

    async def evaluate(self, opportunity, ctx):
        raise NotImplementedError

    async def plan(self, opportunity, ctx):
        raise NotImplementedError

    async def execute(self, plan, ctx):
        raise NotImplementedError

    async def qa(self, result, ctx):
        raise NotImplementedError

    async def deliver(self, result, ctx):
        raise NotImplementedError

    async def learn(self, outcome, ctx):
        raise NotImplementedError
