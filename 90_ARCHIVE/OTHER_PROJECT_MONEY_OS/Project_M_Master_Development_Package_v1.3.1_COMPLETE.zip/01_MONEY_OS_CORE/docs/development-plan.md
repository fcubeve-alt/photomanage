# Development Plan

S0 Repository Foundation
S1 Economic Core
S2 Model + Observability
S3 Tool Layer
S4 Opportunity Core
S5 Agent Core
S6 Economic Memory
S7 M1 Plugin
S8 Dashboard
S9 Real-world Pilot

Do not skip sprint acceptance criteria.
