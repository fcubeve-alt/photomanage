# M1 — AI Digital Worker

Priority A:
- Coding / bug fixing
- Scripts / automation
- Research
- Data cleaning / transformation

Priority B:
- Landing pages / simple websites
- Structured documents / presentations
- SEO research

Excluded:
- AI-forbidden jobs
- illegal/deceptive work
- fabricated identity/experience
- spam
- high-risk legal/medical/financial judgment
- low-value bulk content farms

Lifecycle:
discover → normalize → hard_filter → evaluate → score_economics
→ approval → plan → execute → qa → deliver
→ record_financials → learn → close

Pilot:
- Maximum loss budget: $100
- Every task has max_ai_spend
- One low-cost repair retry before escalation
- First real delivery requires human approval
