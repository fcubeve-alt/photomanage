# API Skeleton

POST /v1/opportunities/ingest
GET  /v1/opportunities
POST /v1/opportunities/{id}/evaluate
POST /v1/opportunities/{id}/decision

POST /v1/tasks
GET  /v1/tasks/{id}
POST /v1/tasks/{id}/run
POST /v1/tasks/{id}/cancel

GET  /v1/runs/{id}

GET  /v1/approvals
POST /v1/approvals/{id}/approve
POST /v1/approvals/{id}/reject

GET  /v1/ledger
GET  /v1/dashboard/summary
GET  /v1/memory/search
