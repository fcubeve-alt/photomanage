# Domain Model

Entities:
- Workspace
- MoneyEngine
- Project
- Source
- Opportunity
- Evidence
- Task
- Run
- ApprovalRequest
- LedgerEntry
- Budget
- EconomicOutcome
- EconomicMemory

Invariants:
- Every paid Run references a Budget.
- Every Revenue/Cost creates a LedgerEntry.
- EconomicMemory references verified outcomes.
- High-risk external actions require ApprovalRequest.
