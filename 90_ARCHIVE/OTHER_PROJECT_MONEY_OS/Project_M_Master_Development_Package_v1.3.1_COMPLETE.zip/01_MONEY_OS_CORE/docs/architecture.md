# Architecture

External Sources / Existing Assets
→ Tool & Ingestion Layer
→ Opportunity Router
→ Economic Scoring
→ Money Engine Manager
→ Agent Orchestrator
→ Builder / QA
→ Approval Gate
→ Delivery
→ Financial Ledger
→ Economic Memory
→ Capital Allocation

## Build
- Money Engine plugin contract
- Opportunity scoring
- Economic model routing
- Budget Manager
- Financial Ledger
- Approval/Risk Policy
- Economic Memory
- Capital Allocation

## Borrow
- LiteLLM-like model gateway
- PraisonAI-like agent framework
- Langfuse-like observability
- Stagehand/Playwright browser layer
- Agent Reach / Last30Days capability layer
- PostgreSQL + pgvector
- MCP/connectors

## Core principle
The real product is the Economic Control Plane, not a single agent.
