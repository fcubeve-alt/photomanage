# M2 Sprint Plan

## M2-S0 Read-only foundation
- register LUVYMIA as M2 asset
- Shopify read adapter
- GA4 read adapter
- GSC read adapter
- site crawler/read-only audit
- baseline snapshot

## M2-S1 Registries
- Asset Registry
- Claim Registry
- Change Registry
- Experiment Registry
- Channel Registry

## M2-S2 Hygiene + Trust
- broken link checks
- spelling/brand consistency
- metadata/schema checks
- claim verification/removal queue
- FAQ/shipping/returns/trust audit

## M2-S3 Measurement
- KPI snapshots
- attribution events
- channel tagging
- profit calculation
- pending outcome windows

## M2-S4 CRO + SEO
- low-risk page experiments
- internal links
- existing-page SEO
- content opportunity scoring

## M2-S5 Growth
- email workflow
- social content workflow
- ambassador workflow
- channel economics

## M2-S6 Scoped Autonomy
- scope approval policies
- auto-publish only proven low-risk actions
- automatic rollback rules
- autonomy promotion/demotion

## M2-S7 Pilot
- run Zero-to-Revenue experiment
- First Order / $100 Revenue / Profitable Week milestones
- final economic report
