# Metrics

## North Star
Realized Net Profit = Revenue - COGS - platform/payment fees - refunds - AI cost - tool cost - paid acquisition - other attributable operating costs.

## Milestones
First Qualified Visitor → First Add-to-Cart → First Checkout → First Order → First $100 Revenue → First Profitable Week → First Profitable Month.

## Leading metrics
Sessions, qualified sessions, organic impressions/clicks, CTR, add-to-cart rate, checkout rate, CVR, AOV, email signups, ambassador leads, CAC, channel contribution margin.

## Human effort
Track human_minutes separately. The goal is not fake autonomy obtained by hidden human labor.
