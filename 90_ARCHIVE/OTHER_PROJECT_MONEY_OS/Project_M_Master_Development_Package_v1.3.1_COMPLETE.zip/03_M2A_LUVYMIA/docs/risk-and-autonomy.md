# Risk and Autonomy Policy

A0 read only.
A1 recommendation only.
A2 create draft; human approves publish.
A3 auto-execute inside approved scope.
A4 create/run/measure/rollback experiments inside approved scope.
A5 allocate bounded operating capital among approved channels.

Never auto-grant A5. Promotion requires verified positive outcomes and no material policy violations.

High-risk: payments, refunds, account permissions, legal commitments, material price/inventory changes. These remain human-gated.
