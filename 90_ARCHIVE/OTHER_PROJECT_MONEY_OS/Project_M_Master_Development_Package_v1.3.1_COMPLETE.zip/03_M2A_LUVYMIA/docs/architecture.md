# M2 Architecture

Money OS Core
→ M2 Manager
→ Asset Registry
→ Observation Layer (Shopify / GA4 / GSC / channel adapters)
→ Opportunity Generator
→ Economic Prioritizer
→ Experiment Planner
→ Scope Approval Gate
→ Workflow Router
→ Change Registry
→ Measurement + Attribution Engine
→ Operating Capital Ledger
→ Economic Memory

## M2 Opportunity Types
Hygiene, Trust, CRO, Existing SEO, New SEO Content, Email, Social, Ambassador, Merchandising, Retention.

## Autonomy
A0 Observe; A1 Recommend; A2 Draft; A3 Scoped autonomous operation; A4 autonomous experimentation; A5 economic operator.

Autonomy is granted per action type, never globally.
