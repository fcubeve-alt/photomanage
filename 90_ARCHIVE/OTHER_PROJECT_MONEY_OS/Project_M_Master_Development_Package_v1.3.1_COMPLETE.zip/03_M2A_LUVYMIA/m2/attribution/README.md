# Attribution Engine

Record channel/source/campaign/order and experiment exposure where available.
Never claim exact causal attribution when evidence is weak. Store attribution_confidence.
For SEO: existing-page outcomes default to ~28-day maturity; new content supports 30/60/90-day pending windows.
