from pydantic import BaseModel, Field
from typing import Literal, Any
from decimal import Decimal

AutonomyLevel = Literal["A0","A1","A2","A3","A4","A5"]
Decision = Literal["KEEP","SCALE","RETRY","ROLLBACK","KILL","PENDING_OUTCOME"]

class M2Opportunity(BaseModel):
    opportunity_type: str
    asset_id: str
    hypothesis: str
    expected_profit: Decimal = Decimal("0")
    estimated_cost: Decimal = Decimal("0")
    risk_level: str = "R1"
    evidence_ids: list[str] = Field(default_factory=list)

class ExperimentPlan(BaseModel):
    opportunity_id: str
    hypothesis: str
    primary_metric: str
    guardrail_metrics: list[str] = Field(default_factory=list)
    observation_days: int
    ai_budget: Decimal
    operating_capital_budget: Decimal = Decimal("0")
    kill_conditions: list[str]
    rollback_plan: str
    required_autonomy: AutonomyLevel

class ExperimentOutcome(BaseModel):
    experiment_id: str
    decision: Decision
    revenue: Decimal = Decimal("0")
    realized_net_profit: Decimal = Decimal("0")
    ai_cost: Decimal = Decimal("0")
    operating_cost: Decimal = Decimal("0")
    attribution_confidence: float = 0
    metrics: dict[str, Any] = Field(default_factory=dict)
