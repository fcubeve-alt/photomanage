CREATE TABLE IF NOT EXISTS m2_assets (
 id UUID PRIMARY KEY, workspace_id UUID NOT NULL, asset_type TEXT NOT NULL, name TEXT NOT NULL, external_ref TEXT, status TEXT NOT NULL, metadata JSONB NOT NULL DEFAULT '{}'::jsonb
);
CREATE TABLE IF NOT EXISTS m2_claims (
 id UUID PRIMARY KEY, asset_id UUID NOT NULL REFERENCES m2_assets(id), claim_text TEXT NOT NULL, status TEXT NOT NULL, evidence_ref TEXT, verified_at TIMESTAMPTZ, risk_level TEXT NOT NULL DEFAULT 'R1', allowed_usage JSONB NOT NULL DEFAULT '{}'::jsonb
);
CREATE TABLE IF NOT EXISTS m2_changes (
 id UUID PRIMARY KEY, asset_id UUID NOT NULL REFERENCES m2_assets(id), experiment_id UUID, change_type TEXT NOT NULL, target_ref TEXT NOT NULL, before_snapshot TEXT, after_snapshot TEXT, reason TEXT NOT NULL, agent_role TEXT, ai_cost NUMERIC(18,8) NOT NULL DEFAULT 0, approval_ref TEXT, rollback_ref TEXT, published_at TIMESTAMPTZ, status TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS m2_experiments (
 id UUID PRIMARY KEY, asset_id UUID NOT NULL REFERENCES m2_assets(id), opportunity_type TEXT NOT NULL, hypothesis TEXT NOT NULL, primary_metric TEXT NOT NULL, status TEXT NOT NULL, started_at TIMESTAMPTZ, maturity_at TIMESTAMPTZ, ai_budget NUMERIC(18,8) NOT NULL DEFAULT 0, operating_capital_budget NUMERIC(18,8) NOT NULL DEFAULT 0, decision TEXT
);
CREATE TABLE IF NOT EXISTS m2_attribution_events (
 id UUID PRIMARY KEY, experiment_id UUID REFERENCES m2_experiments(id), event_type TEXT NOT NULL, channel TEXT, source TEXT, campaign TEXT, order_ref TEXT, revenue NUMERIC(18,8), occurred_at TIMESTAMPTZ NOT NULL, metadata JSONB NOT NULL DEFAULT '{}'::jsonb
);
