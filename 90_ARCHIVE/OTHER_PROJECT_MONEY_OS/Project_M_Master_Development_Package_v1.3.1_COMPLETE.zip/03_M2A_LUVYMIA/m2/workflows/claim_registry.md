# Claim Workflow
Extract factual marketing claims → find internal evidence → VERIFIED / UNVERIFIED / REMOVE.
Unverified non-core claims should be removed rather than amplified.
AI must not invent supporting evidence.
