# Growth Workflow
Channels: Email, Social, Ambassador.
Each channel has its own budget, experiment IDs, tagging and contribution margin.
M2 Manager reallocates effort/capital only after evidence.
