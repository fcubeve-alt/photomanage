# CRO Workflow
Observe funnel → find friction → create hypothesis → estimate EV → define guardrails → A/B or bounded change → measure → KEEP/SCALE/ROLLBACK/KILL.
Do not change material pricing without approval.
