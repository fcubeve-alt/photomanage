# SEO Workflow
Prioritize existing asset repair before mass new content.
Use GSC + site inventory + query intent.
Existing page: allow ~28 days. New content: 30/60/90-day pending outcomes.
Do not optimize for article count; optimize for qualified traffic and downstream profit.
