# Hygiene Workflow
Crawl → detect → deterministic validate → rank by loss/risk/cost → create change draft → QA → execute according to scope → record Change ID → monitor.
Examples: broken links, spelling, brand consistency, metadata, schema, duplicate titles.
