# v1.3 AUTONOMY OVERRIDE

Do not reduce this Engine to a pre-scripted automation pipeline. Implement it as an autonomous Business Brain that creates and revises its own strategy/tasks from current evidence, acquires missing capabilities, and continuously iterates. Human escalation is last resort. Shared Kernel remains the source for common infrastructure.

# Project M M2 v0.5 — Master Build Prompt

Implement M2 v0.4 as a plugin inside the existing Project M Money OS. Do not create a second independent platform.

Read README and all docs first.

## Critical architecture rules
1. Reuse Money OS Core Budget Manager, Financial Ledger, Approval Gate, Model Router, Tool Registry and Economic Memory.
2. M2 adds Asset, Claim, Change, Experiment and Attribution domain objects.
3. Keep AI/Tool Budget separate from Operating Capital.
4. All production writes require a Change ID and rollback metadata where reversible.
5. Every factual marketing claim must resolve through Claim Registry.
6. Autonomy is per action type and scope, not global.
7. Start read-only. Do not request production write credentials in M2-S0.
8. Tool/API first; browser only when necessary.
9. Deterministic checks do not use frontier LLMs.
10. Do not optimize for content volume. Optimize for Realized Net Profit.

## Build strictly in this order
M2-S0 Read-only Foundation
M2-S1 Registries
M2-S2 Hygiene + Trust
M2-S3 Measurement + Attribution
M2-S4 CRO + SEO
M2-S5 Growth
M2-S6 Scoped Autonomy
M2-S7 Zero-to-Revenue Pilot

## First task only: M2-S0
- inspect existing Project M repository and locate plugin interfaces
- register M2 engine without modifying M1 behavior
- create read-only Shopify adapter interface
- create read-only GA4 adapter interface
- create read-only GSC adapter interface
- create site inventory/crawler interface
- implement baseline snapshot schema
- add mocks/fixtures and tests
- produce a credential checklist, but do not require write credentials
- stop after M2-S0 and report files changed, tests, cost impact, security impact and unresolved blockers
