# M2-B Architecture

Money OS Core
→ M2-B Manager
→ Digital Asset Registry
→ Demand/Opportunity Engine
→ Asset Economist
→ Authoritative Source Registry
→ Tool Factory / Content Engine
→ Tax Accuracy Gate
→ SEO Engine
→ Monetization Engine
→ Experiment + Attribution
→ Portfolio Manager
→ shared Financial Ledger + Economic Memory

M2-B-specific data extends Core; it does not duplicate Core services.
