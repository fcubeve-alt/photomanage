# Build Plan

## M2B-S0 Reconciliation + Read-only Baseline
- map existing Monetools code
- inventory tools/pages/articles
- GSC/analytics interfaces
- monetization baseline
- no production writes

## M2B-S1 Registries
- Digital Asset Registry
- Authoritative Source Registry
- Rule Version Registry
- Monetization Registry

## M2B-S2 Accuracy + Hygiene
- tax-year tagging
- formula provenance
- deterministic formula tests
- stale-rule detector
- technical/site hygiene

## M2B-S3 Existing Asset Economics
- traffic/cost/revenue per asset
- qualified visitor definition
- Expected Asset Value
- KEEP/IMPROVE/KILL

## M2B-S4 Tool Factory
- opportunity → spec → code → tests → QA → publish gate

## M2B-S5 Content + SEO
- supporting content
- internal links
- GSC mining
- 30/60/90-day outcome windows

## M2B-S6 Monetization
- affiliate
- ads
- lead/referral
- digital products/email
- channel contribution margin

## M2B-S7 Scoped Autonomy
- A0–A5 per action type
- automatic low-risk execution
- rollback
- capital limits

## M2B-S8 Zero-to-Profit Pilot
- first monetized click/lead
- first revenue
- first $100
- first profitable asset
- portfolio net profit > 0
