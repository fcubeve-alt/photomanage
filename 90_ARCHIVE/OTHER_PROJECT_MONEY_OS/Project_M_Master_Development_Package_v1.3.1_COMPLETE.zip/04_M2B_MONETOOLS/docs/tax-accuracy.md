# Tax Accuracy Gate

Controlled facts cannot come from model memory alone.

Required provenance fields:
- jurisdiction
- tax_year
- rule_key
- official_source_ref
- effective_from
- effective_to
- last_verified_at
- affected_assets
- formula_version
- test_version

Pipeline:
Official Source → Structured Rule → Formula/Content Dependency
→ Tests → QA → Publish.

If source verification fails: HOLD.
