# Autonomy

A0 Observe
A1 Recommend
A2 Draft
A3 Scoped autonomous execution
A4 Scoped autonomous experimentation
A5 Bounded economic operator

Monetools can progress faster toward A3/A4 because many actions are digital and reversible.
A5 still requires verified profit, spend limits, channel scopes and shared Approval Gate.
