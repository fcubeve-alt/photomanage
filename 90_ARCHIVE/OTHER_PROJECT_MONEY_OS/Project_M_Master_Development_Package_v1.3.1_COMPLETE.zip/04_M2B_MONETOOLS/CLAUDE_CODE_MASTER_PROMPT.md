# v1.3 AUTONOMY OVERRIDE

Do not reduce this Engine to a pre-scripted automation pipeline. Implement it as an autonomous Business Brain that creates and revises its own strategy/tasks from current evidence, acquires missing capabilities, and continuously iterates. Human escalation is last resort. Shared Kernel remains the source for common infrastructure.

# Project M — M2-B v0.2 Master Build Prompt

Implement Monetools as **M2-B**, a plugin under the existing Project M Money OS.

Do not create a separate platform.

## First
Read the Project M Master Development Package before this package.

## Reuse shared Core
- Budget Manager
- Financial Ledger
- Approval Gate
- Model Router/Gateway
- Agent Orchestrator
- Tool Registry
- Observability
- Economic Memory

## M2-B adds
- Digital Asset Registry
- Authoritative Source Registry
- Rule/Tax-Year Versioning
- Tool Factory
- Content/SEO workflows
- Monetization Registry
- Asset Economics
- Experiment/Attribution
- Autonomy scopes

## Hard rules
1. Do not build an AI blog spam system.
2. Controlled tax facts require authoritative provenance.
3. Formula changes require deterministic tests.
4. Every asset has economic accounting.
5. SEO may remain PENDING_OUTCOME.
6. AI/Tool Budget and Operating Capital are separate.
7. Start read-only.
8. No production writes before scope/approval policy exists.
9. M1 and M2-A behavior must not regress.

## First task only: M2B-S0
Produce a Monetools Repository Reconciliation + Baseline implementation:
- inspect existing Monetools repository
- inventory existing tools/pages/articles
- map analytics/GSC availability
- identify current monetization integrations
- map formulas and tax-year dependencies
- create read-only asset inventory adapter
- create baseline snapshot schema
- create mocks/tests
- report what can be reused vs changed

Stop after M2B-S0.
