from pydantic import BaseModel, Field
from decimal import Decimal
from typing import Literal

AssetDecision = Literal["BUILD","WATCH","RESEARCH","KILL"]
PortfolioDecision = Literal["KEEP","IMPROVE","SCALE","KILL","PENDING_OUTCOME"]

class DigitalAssetCandidate(BaseModel):
    asset_type: str
    topic: str
    user_intent: str
    demand_score: float
    commercial_intent_score: float
    competition_score: float
    monetization_score: float
    tax_accuracy_risk: float
    estimated_build_cost: Decimal
    confidence: float

class AssetEconomicSnapshot(BaseModel):
    asset_id: str
    qualified_visits: int = 0
    revenue: Decimal = Decimal("0")
    ai_cost: Decimal = Decimal("0")
    tool_cost: Decimal = Decimal("0")
    operating_cost: Decimal = Decimal("0")
    human_minutes: int = 0
    realized_net_profit: Decimal = Decimal("0")

class SourceRule(BaseModel):
    rule_key: str
    jurisdiction: str
    tax_year: int
    official_source_ref: str
    effective_from: str | None = None
    effective_to: str | None = None
    formula_version: str | None = None
    affected_asset_ids: list[str] = Field(default_factory=list)
