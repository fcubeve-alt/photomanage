CREATE TABLE IF NOT EXISTS m2b_assets (
 id UUID PRIMARY KEY,
 workspace_id UUID NOT NULL,
 asset_type TEXT NOT NULL,
 slug TEXT NOT NULL,
 title TEXT NOT NULL,
 lifecycle_state TEXT NOT NULL,
 tax_year INTEGER,
 build_ai_cost NUMERIC(18,8) NOT NULL DEFAULT 0,
 lifetime_ai_cost NUMERIC(18,8) NOT NULL DEFAULT 0,
 maintenance_cost NUMERIC(18,8) NOT NULL DEFAULT 0,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 UNIQUE(workspace_id, slug)
);

CREATE TABLE IF NOT EXISTS m2b_asset_snapshots (
 id UUID PRIMARY KEY,
 asset_id UUID NOT NULL REFERENCES m2b_assets(id),
 snapshot_at TIMESTAMPTZ NOT NULL,
 qualified_visits BIGINT NOT NULL DEFAULT 0,
 revenue NUMERIC(18,8) NOT NULL DEFAULT 0,
 ai_cost NUMERIC(18,8) NOT NULL DEFAULT 0,
 tool_cost NUMERIC(18,8) NOT NULL DEFAULT 0,
 operating_cost NUMERIC(18,8) NOT NULL DEFAULT 0,
 human_minutes INTEGER NOT NULL DEFAULT 0,
 realized_net_profit NUMERIC(18,8) NOT NULL DEFAULT 0
);
