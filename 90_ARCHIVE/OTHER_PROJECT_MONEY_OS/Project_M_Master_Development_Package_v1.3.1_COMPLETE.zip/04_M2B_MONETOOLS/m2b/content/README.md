# Content Engine

Priority:
1. improve existing tool pages
2. supporting content for high-EV tools
3. internal linking
4. commercial decision content
5. standalone content only when EAV supports it

No article-count KPI.
