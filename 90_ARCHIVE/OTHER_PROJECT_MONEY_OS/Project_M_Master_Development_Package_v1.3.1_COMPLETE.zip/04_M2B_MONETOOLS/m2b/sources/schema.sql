CREATE TABLE IF NOT EXISTS m2b_source_rules (
 id UUID PRIMARY KEY,
 rule_key TEXT NOT NULL,
 jurisdiction TEXT NOT NULL,
 tax_year INTEGER NOT NULL,
 official_source_ref TEXT NOT NULL,
 source_hash TEXT,
 effective_from DATE,
 effective_to DATE,
 last_verified_at TIMESTAMPTZ,
 formula_version TEXT,
 test_version TEXT,
 status TEXT NOT NULL,
 UNIQUE(rule_key, jurisdiction, tax_year)
);

CREATE TABLE IF NOT EXISTS m2b_rule_dependencies (
 rule_id UUID NOT NULL REFERENCES m2b_source_rules(id),
 asset_id UUID NOT NULL,
 dependency_type TEXT NOT NULL,
 PRIMARY KEY(rule_id, asset_id, dependency_type)
);
