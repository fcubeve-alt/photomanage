# Tool Factory

Opportunity
→ Tool Spec
→ Rule Resolution
→ Implementation
→ Unit Tests
→ Edge Cases
→ UX Copy
→ SEO Landing Page
→ Accuracy Gate
→ Performance/Accessibility QA
→ Publish Gate.

A tool cannot publish if required controlled rules are unresolved.
