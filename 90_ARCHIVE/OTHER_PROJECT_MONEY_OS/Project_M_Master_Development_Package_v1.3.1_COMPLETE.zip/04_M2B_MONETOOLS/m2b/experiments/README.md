# Experiment Engine

Every experiment:
hypothesis
expected upside
cost
primary metric
guardrails
maturity window
kill condition
rollback
outcome
attribution confidence
economic memory.

Traffic uplift alone is not success.
