# Monetization Engine

Supported channel classes:
- affiliate
- advertising
- qualified lead/referral
- digital product
- email/newsletter
- future premium tool

Each channel records revenue, conversion, cost, contribution margin and policy risk.
New commercial contracts/spend require the appropriate Approval/Scope policy.
