# SEO Engine

Inputs:
GSC queries, site inventory, index status, internal-link graph, asset economics.

Existing asset maturity: ~28 days.
New tool/content: 30/60/90-day windows.
Allow PENDING_OUTCOME.

Optimize qualified traffic and downstream economics, not raw impressions.
