# Project M — Master Development Package v1.3.1 COMPLETE

This is the current canonical Project M package.

## The core idea
Project M is NOT one centralized business brain.

It is:
1. a shared **Money OS Kernel**;
2. multiple independent **Autonomous Business Brains**;
3. real business assets/markets.

M1, M2-A, M2-B and M2-C are not passive plugins. Each is the autonomous owner/operator of its mission domain.

## Genetic rule
Every Business Brain inherits the Autonomous Business Constitution:
Mission Ownership, Autonomy by Default, Mandatory Self-Iteration, Fresh Evidence First, Reuse Before Build, Capability Acquisition, Access Recovery, Solve Before Escalate and Continuous Operation.

## Current engines
- M1 Autonomous Digital Labor Business
- M2-A LUVYMIA Autonomous Commerce Business
- M2-B Monetools Autonomous Digital Asset Business
- M2-C Cubewithin Autonomous Community & Brand Business — DESIGNED / NOT ACTIVE

Give this package, not older Master packages, to the coding lead.
